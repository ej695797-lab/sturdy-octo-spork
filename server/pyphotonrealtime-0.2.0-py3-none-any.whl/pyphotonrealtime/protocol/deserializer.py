from __future__ import annotations

import struct
from io import BytesIO
from typing import TYPE_CHECKING, cast

from pyphotonrealtime.protocol.command_code import CommandCode
from pyphotonrealtime.protocol.operation_code import OperationCode
from pyphotonrealtime.protocol.param.read_param import read_parameter
from pyphotonrealtime.protocol.protocol18 import (
    read_parameter_table,
    read_response_header,
)
from pyphotonrealtime.protocol.serialization_protocol import SerializationProtocol

if TYPE_CHECKING:
    from typing import Any

    from pyphotonrealtime.protocol.packet.header import PhotonDataPacketHeader
    from pyphotonrealtime.protocol.param.base import ParameterBase
    from pyphotonrealtime.protocol.param.parameter_key import ParameterKey


def deserialize_photon_payload(
    header: PhotonDataPacketHeader,
    data: bytes,
    protocol: SerializationProtocol = SerializationProtocol.V16,
) -> tuple[
    OperationCode,
    dict[ParameterKey, ParameterBase[Any]],
    tuple[int, ParameterBase[Any]] | None,
]:
    stream = BytesIO(data)

    is_response = header.command in (
        CommandCode.OperationResponse,
        CommandCode.KeyExchangeResponse,
        CommandCode.EncryptedOperationResponse,
        CommandCode.DisconnectMessage,
    )
    skip_operation_code = header.command == CommandCode.DisconnectMessage

    operation_code = OperationCode.DiffieHellmanRequest
    if not skip_operation_code:
        operation_code = cast("OperationCode", struct.unpack(">B", stream.read(1))[0])

    if protocol == SerializationProtocol.V18:
        debug = read_response_header(stream) if is_response else None
        return (
            operation_code,
            cast(
                "dict[ParameterKey, ParameterBase[Any]]", read_parameter_table(stream)
            ),
            debug,
        )

    response_debug_data = None
    if is_response:
        return_code = struct.unpack(">h", stream.read(2))[0]

        debug_message_param = read_parameter(stream)

        response_debug_data = (return_code, debug_message_param)

    param_count = struct.unpack(">h", stream.read(2))[0]

    params: dict[ParameterKey, ParameterBase[Any]] = {}
    for _ in range(param_count):
        key_bytes = stream.read(1)
        if not key_bytes:
            break
        param_key = cast("ParameterKey", struct.unpack(">B", key_bytes)[0])

        params[param_key] = read_parameter(stream)

    return operation_code, params, response_debug_data
